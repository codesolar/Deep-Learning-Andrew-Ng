# create a vector
from numpy import array
# define vector
v = array([1, 2, 3])
print(v)